from copy import deepcopy
import numpy as np

class SchedulerCSP:
    def __init__(self, courses, professors, loc_info_dict, course_info_dict, time_slots):
        """
        Initialize the Scheduling CSP.
        
        Args:
            courses: list of course names
            professors: list of professor names
            loc_info_dict: dictionary mapping location names to capacity
            course_info_dict: dictionary mapping course names to tuples of 
                             (preferred_professors, student_count, duration, prereq_courses)
            time_slots: list of available time slots
        """
        self.variables = courses
        self.professors = professors
        self.loc_info_dict = loc_info_dict
        self.course_info_dict = course_info_dict
        self.time_slots = time_slots
        
        self.domains = {}
        self.adjacency = {}
        
        self._initialize_domains()
        self._initialize_adjacency()
    
    def _initialize_domains(self):
        """Initialize the domains for each course variable."""
        for course in self.variables:
            self.domains[course] = []
            
            preferred_profs, num_students, duration, _ = self.course_info_dict[course]
            
            # Add all possible combinations of (professor, location, start_time)
            for prof in preferred_profs:
                for loc_name, capacity in self.loc_info_dict.items():
                    if capacity >= num_students:  # Ensure location capacity is sufficient
                        max_start_time = len(self.time_slots) - duration
                        for start_time in range(max_start_time + 1):
                            self.domains[course].append((prof, loc_name, start_time))
    
    def _initialize_adjacency(self):
        """Initialize the adjacency graph of variables based on constraints."""
        for var in self.variables:
            self.adjacency[var] = [
                other_var for other_var in self.variables if var != other_var
            ]
    
    def constraint_consistent(self, var1, val1, var2, val2):
        """
        Check if the assignment of val1 to var1 and val2 to var2 satisfies all constraints.
        """
        prof1, loc1, start_time1 = val1
        prof2, loc2, start_time2 = val2
        
        _, _, duration1, prereqs1 = self.course_info_dict[var1]
        _, _, duration2, prereqs2 = self.course_info_dict[var2]
        
        end_time1 = start_time1 + duration1
        end_time2 = start_time2 + duration2
        
        # Prerequisite constraints
        if var2 in prereqs1 and end_time2 > start_time1:
            return False
        if var1 in prereqs2 and end_time1 > start_time2:
            return False
        
        # Time conflicts for professors
        if prof1 == prof2 and not (end_time1 <= start_time2 or end_time2 <= start_time1):
            return False
        
        # Time conflicts for locations
        if loc1 == loc2 and not (end_time1 <= start_time2 or end_time2 <= start_time1):
            return False
        
        return True
    
    def check_partial_assignment(self, assignment):
        """
        Check if the current partial assignment is consistent.
        
        Args:
            assignment: Dictionary mapping variables to values
            
        Returns:
            True if the assignment is consistent, False otherwise
        """
        for var1, val1 in assignment.items():
            for var2, val2 in assignment.items():
                if var1 != var2 and not self.constraint_consistent(var1, val1, var2, val2):
                    return False
        return True
    
    def is_goal(self, assignment):
        """
        Check if the assignment is complete and consistent.
        """
        return (
            assignment is not None and
            set(assignment.keys()) == set(self.variables) and
            self.check_partial_assignment(assignment)
        )

def backtracking(csp):
    """
    Main backtracking function that sets up the initial domains and 
    calls the recursive helper function.
    """
    current_domains = deepcopy(csp.domains)
    is_consistent, updated_domains = ac3(csp, current_domains=current_domains)
    
    if is_consistent:
        return backtracking_helper(csp, {}, updated_domains)
    return None

def backtracking_helper(csp, assignment, current_domains):
    """
    Recursive helper function for backtracking search.
    """
    if csp.is_goal(assignment):
        return assignment
    
    var = select_unassigned_variable(csp, assignment, current_domains)
    if var is None:
        return None
    
    for val in order_domain_values(csp, var, assignment, current_domains):
        assignment[var] = val
        if csp.check_partial_assignment(assignment):
            child_domains = deepcopy(current_domains)
            child_domains[var] = [val]
            
            arcs_queue = [(neighbor, var) for neighbor in csp.adjacency[var] if neighbor not in assignment]
            is_consistent, child_domains = ac3(csp, arcs_queue, assignment, child_domains)
            
            if is_consistent:
                result = backtracking_helper(csp, assignment, child_domains)
                if result is not None:
                    return result
        
        assignment.pop(var)
    
    return None

def select_unassigned_variable(csp, assignment, current_domains):
    """
    Select an unassigned variable using the Minimum Remaining Values (MRV) heuristic.
    """
    unassigned = [var for var in csp.variables if var not in assignment]
    if not unassigned:
        return None
    return min(unassigned, key=lambda var: (len(current_domains[var]), -len(csp.adjacency[var])))

def order_domain_values(csp, var, assignment, current_domains):
    """
    Order the values in the domain using the Least Constraining Value (LCV) heuristic.
    """
    def count_conflicts(val):
        return sum(
            not csp.constraint_consistent(var, val, neighbor, n_val)
            for neighbor in csp.adjacency[var] if neighbor not in assignment
            for n_val in current_domains[neighbor]
        )
    return sorted(current_domains[var], key=count_conflicts)

def ac3(csp, arcs_queue=None, current_domains=None):
    """
    AC3 algorithm for enforcing arc consistency.
    """
    if arcs_queue is None:
        arcs_queue = {(var, neighbor) for var in csp.variables for neighbor in csp.adjacency[var]}
    
    if current_domains is None:
        current_domains = deepcopy(csp.domains)
    
    while arcs_queue:
        xi, xj = arcs_queue.pop()
        if revise(csp, xi, xj, current_domains):
            if not current_domains[xi]:
                return False, current_domains
            arcs_queue.update((xk, xi) for xk in csp.adjacency[xi] if xk != xj)
    
    return True, current_domains

def revise(csp, xi, xj, current_domains):
    """
    Revise the domain of xi with respect to xj.
    """
    revised = False
    for valxi in list(current_domains[xi]):
        if not any(csp.constraint_consistent(xi, valxi, xj, valxj) for valxj in current_domains[xj]):
            current_domains[xi].remove(valxi)
            revised = True
    return revised
