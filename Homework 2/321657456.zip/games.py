import chess
import numpy as np
# from typing import List, Tuple, Dict, Any

# Profiler to track function calls
class Profiler:
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.h_minimax_calls = 0
        self.max_node_calls = 0
        self.min_node_calls = 0
    
    def increment_h_minimax(self):
        self.h_minimax_calls += 1
    
    def increment_max_node(self):
        self.max_node_calls += 1
    
    def increment_min_node(self):
        self.min_node_calls += 1

# Create a global profiler instance
profiler = Profiler()

def heuristic_chess(board):
    """
    Evaluate the current state of the chess board.
    Returns a value between -1 and 1, where positive values favor white
    and negative values favor black.
    """
    outcome = board.outcome()
    if outcome is not None:
        # If the game is over, return win/loss/draw values
        if outcome.winner is None:  # Draw
            return 0
        return 1 if outcome.winner else -1

    # Piece values - standard chess piece values
    piece_values = {
        chess.PAWN: 1,
        chess.KNIGHT: 3,
        chess.BISHOP: 3,
        chess.ROOK: 5,
        chess.QUEEN: 9,
        chess.KING: 0  # King's value isn't used for material count
    }

    # Calculate material advantage
    white_material = sum(
        piece_values[piece.piece_type] for square in chess.SQUARES
        if (piece := board.piece_at(square)) and piece.color == chess.WHITE
    )
    black_material = sum(
        piece_values[piece.piece_type] for square in chess.SQUARES
        if (piece := board.piece_at(square)) and piece.color == chess.BLACK
    )

    # Normalize material difference to [-0.9, 0.9]
    material_difference = white_material - black_material
    max_material = sum(piece_values.values()) * 16  # Maximum possible material value
    material_advantage = 0.9 * (material_difference / max_material)
    
    return material_advantage

def is_cutoff(board, current_depth, depth_limit):
    """
    Determine if we should stop the search at this node.
    """
    return current_depth >= depth_limit or board.is_game_over()

# def h_minimax(board, depth_limit):
def h_minimax(board, depth_limit):
    """
    Implementation of the h-minimax algorithm for chess.
    """
    # Reset the profiler before starting a new search
    profiler.reset()
    profiler.increment_h_minimax()
    
    if board.turn == chess.WHITE:
        value, best_move = max_node(board, depth_limit, 0)
    else:
        value, best_move = min_node(board, depth_limit, 0)
    
    return value, best_move
def max_node(board, depth_limit, current_depth):
    profiler.increment_max_node()
    
    if is_cutoff(board, current_depth, depth_limit):
        return heuristic_chess(board), None

    best_value = float('-inf')
    best_move = None
    
    for move in board.legal_moves:
        board.push(move)
        value, _ = min_node(board, depth_limit, current_depth + 1)
        board.pop()

        if value > best_value:
            best_value = value
            best_move = move
            
    return best_value, best_move

def min_node(board, depth_limit, current_depth):
    profiler.increment_min_node()
    
    if is_cutoff(board, current_depth, depth_limit):
        return heuristic_chess(board), None

    best_value = float('inf')
    best_move = None

    for move in board.legal_moves:
        board.push(move)
        value, _ = max_node(board, depth_limit, current_depth + 1)
        board.pop()

        if value < best_value:
            best_value = value
            best_move = move
            
    return best_value, best_move

# def h_minimax_alpha_beta(board, depth_limit):
def h_minimax_alpha_beta(board, depth_limit):
    """
    Implementation of the h-minimax algorithm with alpha-beta pruning for chess.
    """
    # Reset profiler for alpha-beta search
    profiler.reset()
    profiler.increment_h_minimax()
    
    if board.turn == chess.WHITE:
        value, best_move = max_node_ab(board, depth_limit, 0, float('-inf'), float('inf'))
    else:
        value, best_move = min_node_ab(board, depth_limit, 0, float('-inf'), float('inf'))
    
    return value, best_move
def max_node_ab(board, depth_limit, current_depth, alpha, beta):
    profiler.increment_max_node()
    
    if is_cutoff(board, current_depth, depth_limit):
        return heuristic_chess(board), None

    best_value = float('-inf')
    best_move = None
    
    for move in board.legal_moves:
        board.push(move)
        value, _ = min_node_ab(board, depth_limit, current_depth + 1, alpha, beta)
        board.pop()

        if value > best_value:
            best_value = value
            best_move = move
            
        alpha = max(alpha, best_value)
        if alpha >= beta:  # Beta cutoff
            break

    return best_value, best_move

def min_node_ab(board, depth_limit, current_depth, alpha, beta):
    profiler.increment_min_node()
    
    if is_cutoff(board, current_depth, depth_limit):
        return heuristic_chess(board), None

    best_value = float('inf')
    best_move = None

    for move in board.legal_moves:
        board.push(move)
        value, _ = max_node_ab(board, depth_limit, current_depth + 1, alpha, beta)
        board.pop()

        if value < best_value:
            best_value = value
            best_move = move

        beta = min(beta, best_value)
        if alpha >= beta:  # Alpha cutoff
            break

    return best_value, best_move
